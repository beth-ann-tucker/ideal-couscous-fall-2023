$( document ).ready(function() {
  
  //allow user to interact with doge by clicking on his immage to reveal a wow message
  $('#hidingDoge').click(
    function(
    ){
      $('#expressWow').text("WOW, you spotted doge, many wows, wow WOW wow WOW wow!");
    }
);
});